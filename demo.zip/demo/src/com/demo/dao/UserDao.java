package com.demo.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import com.demo.model.User;
import com.demo.util.Md5Encrypt;

public class UserDao {
	private SessionFactory sessionFactory;

	public User queryUser(String name, String password) {
		String sql = "from User where name=? and password=?";
		Session session = sessionFactory.getCurrentSession();
		User u = null;
		try {
			Query query = session.createQuery(sql).setString(0, name)
					.setString(1, Md5Encrypt.md5(password));
			u = (User) query.uniqueResult();
		} catch (RuntimeException e) {
			throw e;
		}
		return u;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}
}
