package com.demo.action;

import com.demo.service.UserService;
import com.opensymphony.xwork2.ActionSupport;

@SuppressWarnings("serial")
public class UserAction extends ActionSupport {
	private String name;
	private String password;
	private UserService userService;

	public String login() {
		if (name == null || password == null) {
			return "input";
		} else if (userService.login(name, password)) {
			return "ok";
		}
		return "error";
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return password;
	}

	public void setUserService(UserService userService) {
		this.userService = userService;
	}

	public UserService getUserService() {
		return userService;
	}
}
