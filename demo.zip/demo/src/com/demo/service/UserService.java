package com.demo.service;

import com.demo.dao.UserDao;
import com.demo.model.User;

public class UserService {
	private UserDao userDao;

	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}

	public UserDao getUserDao() {
		return userDao;
	}

	public boolean login(String name, String password) {
		User u = userDao.queryUser(name, password);
		if (u == null) {
			return false;
		}
		return true;
	}
}
